"""
gui_server.py  —  Drop this file next to your main bot file.
Run it alongside the bot:  python gui_server.py
It reads the same SQLite DB, JSON files, and controls the bot process.
"""

import sqlite3
import json
import os
import subprocess
import signal
import threading
import time
from datetime import datetime
from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_sock import Sock

# ── paths must match your bot config ──────────────────────────────────────────
DATABASE          = "ai_trading.db"
SIGNAL_FILE       = "signal_history.json"
OPEN_SIGNALS_FILE = "open_signals.json"
PERFORMANCE_FILE  = "performance_data.json"
BOT_SCRIPT        = "ai_trading_bot_v4.py"
LOG_FILE          = "gui_log.json"        # ← persistent log storage
FILTER_FILE       = "gui_filters.json"

# ── auto-delete threshold ─────────────────────────────────────────────────────
MAX_DATA_SIZE_MB  = 200   # trigger cleanup when total data files exceed 200 MB
DATA_FILES        = [DATABASE, SIGNAL_FILE, OPEN_SIGNALS_FILE,
                     PERFORMANCE_FILE, LOG_FILE]
# ──────────────────────────────────────────────────────────────────────────────

app  = Flask(__name__, static_folder=".", static_url_path="/static")
CORS(app)
sock = Sock(app)

# ── Serve the GUI HTML directly (fixes file:// CORS issues) ──────────────────
@app.route("/")
def index():
    return app.send_static_file("trading_gui.html")

bot_process = None   # subprocess handle
ws_clients  = []     # connected WebSocket clients
bot_lock    = threading.Lock()

# ── persistent log ────────────────────────────────────────────────────────────
_log_lock = threading.Lock()

def _load_gui_log():
    """Load log from disk; returns a list (newest entries at end)."""
    try:
        with open(LOG_FILE) as f:
            data = json.load(f)
            return data if isinstance(data, list) else []
    except Exception:
        return []

def _save_gui_log(log_list):
    """Persist the log list to disk (best-effort, non-blocking)."""
    try:
        with open(LOG_FILE, "w") as f:
            json.dump(log_list, f)
    except Exception:
        pass

# Load existing log on startup (survives server restart)
gui_log = _load_gui_log()

# ── helpers ───────────────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def load_json(path):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return []

def get_data_size_mb():
    """Return total size of all data files in MB."""
    total = 0
    for path in DATA_FILES:
        try:
            total += os.path.getsize(path)
        except OSError:
            pass
    return total / (1024 * 1024)

def auto_cleanup_if_needed():
    """
    If total data files exceed MAX_DATA_SIZE_MB, delete the oldest records:
      - Trim the oldest 20 % of SQLite signal rows
      - Trim the oldest 20 % of signal_history.json entries
      - Trim the oldest 50 % of the in-memory / on-disk gui_log
    Runs in a background thread so it never blocks a request.
    """
    size_mb = get_data_size_mb()
    if size_mb < MAX_DATA_SIZE_MB:
        return

    add_log("warn",
            f"Data size {size_mb:.1f} MB ≥ {MAX_DATA_SIZE_MB} MB — running auto-cleanup")

    # 1) Trim SQLite signals (oldest 20 %)
    try:
        db = sqlite3.connect(DATABASE)
        total_rows = db.execute("SELECT COUNT(*) FROM signals").fetchone()[0]
        delete_cnt = max(1, int(total_rows * 0.20))
        db.execute(
            "DELETE FROM signals WHERE id IN "
            "(SELECT id FROM signals ORDER BY id ASC LIMIT ?)",
            (delete_cnt,)
        )
        db.execute("VACUUM")
        db.commit()
        db.close()
        add_log("warn", f"Auto-cleanup: removed {delete_cnt} old signal rows from DB")
    except Exception as e:
        add_log("err", f"Auto-cleanup DB error: {e}")

    # 2) Trim signal_history.json (keep newest 80 %)
    try:
        history = load_json(SIGNAL_FILE)
        if history:
            keep = max(1, int(len(history) * 0.80))
            trimmed = history[-keep:]
            with open(SIGNAL_FILE, "w") as f:
                json.dump(trimmed, f)
            add_log("warn",
                    f"Auto-cleanup: trimmed signal_history.json "
                    f"({len(history)} → {len(trimmed)} entries)")
    except Exception as e:
        add_log("err", f"Auto-cleanup signal_history error: {e}")

    # 3) Trim in-memory + on-disk gui_log (keep newest 50 %)
    with _log_lock:
        keep = max(50, len(gui_log) // 2)
        del gui_log[:-keep]
        _save_gui_log(gui_log)
    add_log("warn", f"Auto-cleanup: log trimmed to {keep} entries")

    new_size = get_data_size_mb()
    add_log("acc", f"Auto-cleanup complete. Data size now {new_size:.1f} MB")

def add_log(level, msg):
    entry = {
        "time":  datetime.now().strftime("%H:%M:%S"),
        "level": level,
        "msg":   msg
    }
    with _log_lock:
        gui_log.append(entry)
        # Keep in-memory list bounded (1 000 entries max)
        if len(gui_log) > 1000:
            del gui_log[:200]      # drop oldest 200 at once
        _save_gui_log(gui_log)    # persist every write

    broadcast({"type": "log", "data": entry})

    # Kick off size check in the background so we never block a request
    threading.Thread(target=auto_cleanup_if_needed, daemon=True).start()

def broadcast(payload):
    dead = []
    for ws in ws_clients:
        try:
            ws.send(json.dumps(payload))
        except Exception:
            dead.append(ws)
    for ws in dead:
        ws_clients.remove(ws)

def bot_is_running():
    global bot_process
    return bot_process is not None and bot_process.poll() is None

# ── bot process watcher (streams stdout → GUI log) ────────────────────────────

def watch_bot_output(proc):
    for line in iter(proc.stdout.readline, b""):
        text = line.decode("utf-8", errors="replace").rstrip()
        if text:
            level = "err"  if "ERROR" in text.upper() else \
                    "warn" if "WARN"  in text.upper() or "SKIP" in text.upper() else \
                    "acc"
            add_log(level, text)
    add_log("warn", "Bot process ended")
    broadcast({"type": "bot_status", "running": False})

# ═══════════════════════════════════════════════════════════════════════════════
# REST ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/api/status")
def status():
    size_mb = get_data_size_mb()
    return jsonify({
        "bot_running": bot_is_running(),
        "mt5_ok":      os.path.exists(DATABASE),
        "time_utc":    datetime.utcnow().strftime("%H:%M:%S"),
        "data_size_mb": round(size_mb, 2),
        "data_size_pct": round(size_mb / MAX_DATA_SIZE_MB * 100, 1),
    })

# ── scoreboard ────────────────────────────────────────────────────────────────
@app.route("/api/scoreboard")
def scoreboard():
    db = get_db()
    rows = db.execute(
        "SELECT result, COUNT(*) as cnt FROM signals WHERE signal != 'HOLD' GROUP BY result"
    ).fetchall()
    counts = {r["result"]: r["cnt"] for r in rows}

    sym_rows = db.execute("""
        SELECT symbol,
               SUM(CASE WHEN result='WIN'  THEN 1 ELSE 0 END) wins,
               SUM(CASE WHEN result='LOSS' THEN 1 ELSE 0 END) losses,
               COUNT(*) total
        FROM   signals WHERE signal != 'HOLD'
        GROUP  BY symbol
    """).fetchall()
    db.close()

    w = counts.get("WIN", 0)
    l = counts.get("LOSS", 0)
    r = counts.get("RUNNING", 0)
    e = counts.get("EXPIRED", 0)
    total = w + l
    wr = round(w / total * 100, 1) if total else 0.0

    return jsonify({
        "wins": w, "losses": l, "running": r, "expired": e,
        "win_rate": wr,
        "symbols": [dict(row) for row in sym_rows]
    })

# ── recent signals ────────────────────────────────────────────────────────────
@app.route("/api/signals")
def signals():
    db   = get_db()
    rows = db.execute(
        "SELECT * FROM signals ORDER BY id DESC LIMIT 50"
    ).fetchall()
    db.close()
    return jsonify([dict(r) for r in rows])

# ── open signals ──────────────────────────────────────────────────────────────
@app.route("/api/open_signals")
def open_signals():
    return jsonify(load_json(OPEN_SIGNALS_FILE))

# ── signal history (json file) ────────────────────────────────────────────────
@app.route("/api/history")
def history():
    return jsonify(load_json(SIGNAL_FILE)[-50:])

# ── log ───────────────────────────────────────────────────────────────────────
@app.route("/api/log")
def get_log():
    with _log_lock:
        return jsonify(gui_log[-80:])

@app.route("/api/log/clear", methods=["POST"])
def clear_log():
    with _log_lock:
        gui_log.clear()
        _save_gui_log(gui_log)
    return jsonify({"ok": True})

# ── storage info ──────────────────────────────────────────────────────────────
@app.route("/api/storage")
def storage_info():
    details = {}
    for path in DATA_FILES:
        try:
            details[os.path.basename(path)] = round(os.path.getsize(path) / (1024*1024), 3)
        except OSError:
            details[os.path.basename(path)] = 0.0
    total = sum(details.values())
    return jsonify({
        "files":        details,
        "total_mb":     round(total, 2),
        "limit_mb":     MAX_DATA_SIZE_MB,
        "used_pct":     round(total / MAX_DATA_SIZE_MB * 100, 1),
    })

# ── manual cleanup trigger ────────────────────────────────────────────────────
@app.route("/api/storage/cleanup", methods=["POST"])
def force_cleanup():
    threading.Thread(target=auto_cleanup_if_needed, daemon=True).start()
    return jsonify({"ok": True, "msg": "Cleanup triggered"})

# ── bot control ───────────────────────────────────────────────────────────────
@app.route("/api/bot/start", methods=["POST"])
def start_bot():
    global bot_process
    with bot_lock:
        if bot_is_running():
            return jsonify({"ok": False, "msg": "Already running"})
        try:
            bot_process = subprocess.Popen(
                ["python", BOT_SCRIPT],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
            )
            threading.Thread(target=watch_bot_output,
                             args=(bot_process,), daemon=True).start()
            add_log("acc", f"Bot started (PID {bot_process.pid})")
            broadcast({"type": "bot_status", "running": True})
            return jsonify({"ok": True, "pid": bot_process.pid})
        except Exception as e:
            add_log("err", f"Failed to start bot: {e}")
            return jsonify({"ok": False, "msg": str(e)})

@app.route("/api/bot/stop", methods=["POST"])
def stop_bot():
    global bot_process
    with bot_lock:
        if not bot_is_running():
            return jsonify({"ok": False, "msg": "Bot not running"})
        try:
            bot_process.send_signal(signal.SIGTERM)
            bot_process.wait(timeout=5)
        except Exception:
            bot_process.kill()
        add_log("warn", "Bot stopped by user")
        broadcast({"type": "bot_status", "running": False})
        bot_process = None
        return jsonify({"ok": True})

# ── filter overrides ──────────────────────────────────────────────────────────
@app.route("/api/filters", methods=["GET"])
def get_filters():
    try:
        with open(FILTER_FILE) as f:
            return jsonify(json.load(f))
    except Exception:
        defaults = {
            "killzone": True, "calendar": True, "spread": True,
            "volatility": True, "market_quality": True,
            "regime": True, "mtf": True, "telegram": True
        }
        return jsonify(defaults)

@app.route("/api/filters", methods=["POST"])
def set_filters():
    data = request.json
    with open(FILTER_FILE, "w") as f:
        json.dump(data, f, indent=2)
    add_log("info", f"Filters updated: {data}")
    broadcast({"type": "filters", "data": data})
    return jsonify({"ok": True})

# ── clear open signals ────────────────────────────────────────────────────────
@app.route("/api/open_signals/clear", methods=["POST"])
def clear_open():
    with open(OPEN_SIGNALS_FILE, "w") as f:
        json.dump([], f)
    add_log("warn", "Open signals cleared via GUI")
    return jsonify({"ok": True})

# ─── WebSocket (live push) ────────────────────────────────────────────────────
@sock.route("/ws")
def websocket(ws):
    ws_clients.append(ws)
    add_log("info", "GUI connected via WebSocket")
    ws.send(json.dumps({"type": "bot_status", "running": bot_is_running()}))
    # Send current storage info on connect
    size_mb = get_data_size_mb()
    ws.send(json.dumps({
        "type": "storage",
        "data": {
            "total_mb":  round(size_mb, 2),
            "limit_mb":  MAX_DATA_SIZE_MB,
            "used_pct":  round(size_mb / MAX_DATA_SIZE_MB * 100, 1),
        }
    }))
    try:
        while True:
            msg = ws.receive(timeout=30)
            if msg is None:
                break
            data = json.loads(msg)
            if data.get("type") == "ping":
                ws.send(json.dumps({"type": "pong"}))
    except Exception:
        pass
    finally:
        if ws in ws_clients:
            ws_clients.remove(ws)

# ── push new DB rows every 5 s ────────────────────────────────────────────────
def db_poller():
    last_id = 0
    while True:
        time.sleep(5)
        try:
            db   = get_db()
            rows = db.execute(
                "SELECT * FROM signals WHERE id > ? ORDER BY id", (last_id,)
            ).fetchall()
            db.close()
            for row in rows:
                last_id = max(last_id, row["id"])
                broadcast({"type": "new_signal", "data": dict(row)})
        except Exception:
            pass

# ── broadcast storage stats every 30 s ───────────────────────────────────────
def storage_poller():
    while True:
        time.sleep(30)
        try:
            size_mb = get_data_size_mb()
            broadcast({
                "type": "storage",
                "data": {
                    "total_mb":  round(size_mb, 2),
                    "limit_mb":  MAX_DATA_SIZE_MB,
                    "used_pct":  round(size_mb / MAX_DATA_SIZE_MB * 100, 1),
                }
            })
        except Exception:
            pass

threading.Thread(target=db_poller,      daemon=True).start()
threading.Thread(target=storage_poller, daemon=True).start()

# ──────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    add_log("acc", "GUI server started on http://localhost:5000")
    print("=" * 50)
    print("  AI Trading Bot GUI Server")
    print(f"  Log entries loaded from disk: {len(gui_log)}")
    print(f"  Auto-cleanup threshold: {MAX_DATA_SIZE_MB} MB")
    print("  Open  →  http://localhost:5000")
    print("  API   →  http://localhost:5000")
    print("=" * 50)
    app.run(host="0.0.0.0", port=5000, debug=False)
